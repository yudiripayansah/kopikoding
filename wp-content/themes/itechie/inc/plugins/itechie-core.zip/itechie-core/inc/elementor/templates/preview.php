<div>
    <a href="<?php echo esc_url($settings['url']['url']); ?>">
        <img src="<?php echo esc_url($settings['image']['url']); ?>" alt="<?php echo esc_attr(itechie_core_get_thumbnail_alt($settings['image']['id'])); ?>">
    </a>
</div>